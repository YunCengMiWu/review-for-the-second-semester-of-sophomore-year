`timescale 1ns / 1ps
module tb_clk_1Hz_div;

reg clk;
reg clr;
wire clk_1Hz;

// 50MHz系统时钟，周期20ns
initial 
begin
    clk = 1'b0;
    forever #10 clk = ~clk;
end

// 复位激励与仿真时长
initial 
begin
    clr = 1'b0;
    #30;
    clr = 1'b1;
    
    // 仿真2.1s，观察完整1Hz波形
    #2100000000;
    $finish;
end

clk_1Hz_div sim_clk_1Hz_div(
    .clk(clk),
    .clr(clr),
    .clk_1Hz(clk_1Hz)
    );


endmodule