module disp_change (
    input switch,
    input [23:0]timing,
    input [23:0]week,
    input [2:0]bit_sel_time,
    output [23:0]dispdata,
    output [2:0]bit_sel
    );
    
    assign dispdata = (switch) ? week : timing;
    assign bit_sel = (switch) ? 0 : bit_sel_time;

endmodule   