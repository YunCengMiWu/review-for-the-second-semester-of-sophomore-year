transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+G:/intelFPGA_lite/18.1/pjt051827/pjt {G:/intelFPGA_lite/18.1/pjt051827/pjt/dig_disp.v}

vlog -vlog01compat -work work +incdir+G:/intelFPGA_lite/18.1/pjt051827/pjt {G:/intelFPGA_lite/18.1/pjt051827/pjt/tb_dig_disp.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc"  tb_dig_disp

add wave *
view structure
view signals
run -all
