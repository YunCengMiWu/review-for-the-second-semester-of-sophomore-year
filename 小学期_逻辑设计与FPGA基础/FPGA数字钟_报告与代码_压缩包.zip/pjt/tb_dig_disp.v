`timescale 1ns/1ns
module tb_dig_disp;
reg clk;
reg clk_flk;
reg rst;
reg pause;
reg [23:0] dispdata_bcd;
reg [2:0] bit_sel;
reg disp_switch;

wire [5:0] an;
wire [7:0] seg;

dig_disp u_dig_disp(
    .clk(clk),
    .clk_flk(clk_flk),
    .rst(rst),
    .pause(pause),
    .dispdata_bcd(dispdata_bcd),
    .bit_sel(bit_sel),
    .an(an),
    .seg(seg)
);

// 50MHz系统时钟
initial begin
    clk = 1'b0;
	 clk_flk = 1;
    forever #10 clk = ~clk;
end



always @(*) begin
    if(disp_switch == 1'b0) begin
        dispdata_bcd = 24'h123456;
    end
    else begin
        dispdata_bcd = 24'hFFFFF8;
    end
end

initial begin
 
    // 复位
    rst = 1'b0;
    pause = 1'b0;
    bit_sel = 3'd2;
    disp_switch = 1'b0;
    #300;

    rst = 1'b1;
    #4000;

    #120; // disp_bit=2
    #120; // disp_bit=3
    #120; // disp_bit=4
    #120; // disp_bit=5
    #120; // disp_bit=0
    #120; // disp_bit=1


    //切换状态switch=1
    disp_switch = 1'b1;
    pause = 1'b0;
    #4000;

    rst = 1'b0;
    #300;

    $finish;
end

endmodule