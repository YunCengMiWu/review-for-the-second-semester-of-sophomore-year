//数码管动态显示
module dig_disp (
    input clk,
    input clk_flk, //位闪烁频率
    input rst,
    input pause,
    input [23:0]dispdata_bcd, //4*6=24位bcd码
    input [2:0]bit_sel, //调节位0~5
    output [5:0]an, //数码管6位片选信号
    output reg [7:0]seg //8位段选信号
    );
    reg [4:0]disp_dat; //当前显示的位的BCD码,非法码用于考虑数码管全灭
    reg [2:0]disp_bit; //扫描计数器0~5循环，依次选中6个数码管

    assign an = (rst) ?  ~(1 << disp_bit): 6'b11_1111;

    always @(posedge clk or negedge rst)
    begin
        if (!rst)
        begin
            disp_bit <= 2;
        end
        else
        begin
            disp_bit <= (disp_bit < 5) ? disp_bit + 1 : 0;
        end
    end

    always @(*)
    begin
        if (!rst)
        begin
            disp_dat = 4'b1111;
        end
        else
        begin
            if (pause && clk_flk && (disp_bit == bit_sel))
            begin
                disp_dat = 4'b1111;
            end
            else
            begin
                disp_dat = (dispdata_bcd >> (disp_bit * 4)) & 4'hF;
            end

            case (disp_bit)
                2,4: //小数点间隔时分秒
                begin
                    case(disp_dat)
                        4'h0: seg = 8'hbf;
                        4'h1: seg = 8'h86;
                        4'h2: seg = 8'hdb;
                        4'h3: seg = 8'hcf;
                        4'h4: seg = 8'he6;
                        4'h5: seg = 8'hed;
                        4'h6: seg = 8'hfd;
                        4'h7: seg = 8'h87;
                        4'h8: seg = 8'hff;
                        4'h9: seg = 8'hef;
                        default: seg = 0;
                    endcase
                end
                default: //其他位无小数点
                begin   
                    case (disp_dat)
                        4'h0: seg = 8'h3f;
                        4'h1: seg = 8'h06;
                        4'h2: seg = 8'h5b;
                        4'h3: seg = 8'h4f;
                        4'h4: seg = 8'h66;
                        4'h5: seg = 8'h6d;
                        4'h6: seg = 8'h7d;
                        4'h7: seg = 8'h07;
                        4'h8: seg = 8'h7f;
                        4'h9: seg = 8'h6f;
                        default: seg = 0;
                    endcase
                end
            endcase
        end
    end
endmodule