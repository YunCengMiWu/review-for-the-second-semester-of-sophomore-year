
module bin_to_bcd(
    input [5:0]bin, //输入6位二进制，[log_2(60)]+1=6
    output [7:0]bcd //输出8位BCD码，2*4=8
    );
    reg [3:0]units;
    reg [3:0]tens;
    integer i;

    assign bcd = {tens, units};

    always @(*)
    begin
        units = 0;  // 清零
        tens = 0;

        for (i=5; i>=0; i=i-1)
        begin
            if (units >= 5) //大于等于5则+3修正 		
            begin
                units = units + 3;
            end
            if (tens >= 5) 		
            begin
                tens = tens + 3;
            end

            tens = {tens[2:0], units[3]};//移位
            units = {units[2:0], bin[i]};
        end
    end
endmodule
