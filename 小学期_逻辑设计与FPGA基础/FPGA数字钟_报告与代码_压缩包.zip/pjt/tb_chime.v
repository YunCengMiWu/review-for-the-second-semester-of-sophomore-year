`timescale 1ns/1ns
module tb_chime;

reg clk_2kHz;
reg clk_800Hz;
reg pause;
reg [5:0] min;
reg [5:0] sec;
wire buzzer;

chime u_chime(
    .clk_2kHz(clk_2kHz),
    .clk_800Hz(clk_800Hz),
    .pause(pause),
    .min(min),
    .sec(sec),
    .buzzer(buzzer)
);

// 2kHz时钟 周期500ns
initial begin
    clk_2kHz = 1'b0;
    forever #250 clk_2kHz = ~clk_2kHz;
end

// 800Hz时钟 周期1250ns
initial begin
    clk_800Hz = 1'b0;
    forever #625 clk_800Hz = ~clk_800Hz;
end

initial begin
    pause = 1'b1;
    min = 6'd0;
    sec = 6'd0;
    #1000;

    pause = 1'b0;
    // 00:00 ~ 59:59
    for(min = 0; min <= 59; min = min + 1) begin
        for(sec = 0; sec <= 59; sec = sec + 1) begin
            #1000;
        end
    end
    // 回到00:00
    min = 6'd0;
    sec = 6'd0;
    #2000;

    $finish;
end
endmodule