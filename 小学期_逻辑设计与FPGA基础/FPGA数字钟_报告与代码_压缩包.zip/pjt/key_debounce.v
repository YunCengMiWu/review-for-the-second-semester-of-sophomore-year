module key_debounce(
    input btn_clk,
    input rst,
    input btn_in,
    output btn_out
    );
    reg btn0;
    reg btn1;
    reg btn2;

    assign btn_out = btn0 | btn1 | btn2;
    
    always @(posedge btn_clk or negedge rst) //时钟上升沿来临（消抖同步）或复位信号下降沿出现（复位异步）
        begin
            if (!rst)
                begin
                    btn0 <= 1;
                    btn1 <= 1;
                    btn2 <= 1;
                end
            else
                begin
                    btn0 <= btn_in;
                    btn1 <= btn0;
                    btn2 <= btn1;
                end
        end
endmodule