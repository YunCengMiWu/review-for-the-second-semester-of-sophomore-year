module timer(
    input clk,
    input clk_50MHz,
    input rst,
    input pause, //拨码开关调节暂停与计时模式
    input switch, //切换显示时分秒和星期
    input plus, //增按钮
    input minus, //减按钮
    input left, //左移按钮
    input right, //右移按钮
    output reg [2:0]bit_sel, //调节位0~6
    output reg [5:0]hour,
    output reg [5:0]min,
    output reg [5:0]sec,
    output reg [3:0]week
    );

    reg [5:0] hour_next;
    reg [5:0] min_next;
    reg [5:0] sec_next;
    reg [3:0] week_next;

    
    reg plus_d1, plus_d2; 
    reg minus_d1, minus_d2;
    reg left_d1, left_d2;
    reg right_d1, right_d2;
    reg clk_d1, clk_d2;

    wire plus_pulse = ~plus_d1 & plus_d2; //单周期脉冲信号
    wire minus_pulse = ~minus_d1 & minus_d2;
    wire left_pulse = ~left_d1 & left_d2;
    wire right_pulse = ~right_d1 & right_d2;
    wire clk_pulse = clk_d1 & ~clk_d2;


    always @(posedge clk_50MHz or negedge rst) //按键打拍
        begin
            if (!rst) 
            begin
                plus_d1 <= 1; 
                plus_d2 <= 1;
                minus_d1 <= 1; 
                minus_d2 <= 1;
                left_d1 <= 1; 
                left_d2 <= 1;
                right_d1 <= 1; 
                right_d2 <= 1;
                clk_d1 <= 0;
                clk_d2 <= 0;
            end 
            else 
            begin
                plus_d1 <= plus; 
                plus_d2 <= plus_d1;
                minus_d1 <= minus; 
                minus_d2 <= minus_d1;
                left_d1 <= left; 
                left_d2 <= left_d1;
                right_d1 <= right; 
                right_d2 <= right_d1;
                clk_d1 <= clk;
                clk_d2 <= clk_d1;
            end
        end



    always @(*) //计算下一时刻
    begin
        sec_next = sec;
        min_next = min;
        hour_next = hour;
        week_next = week;
        if (sec < 59)
        begin
            sec_next = sec + 1;
        end
        else
        begin
            sec_next = 0;
            if (min < 59)
            begin
                min_next = min + 1;
            end
            else
            begin
                min_next = 0;
                if (hour < 23)
                begin
                    hour_next = hour + 1;
                end
                else 
                begin
                    hour_next = 0;
                    case (week)
                        1: week_next = 2;
                        2: week_next = 3;
                        3: week_next = 4;
                        4: week_next = 5;
                        5: week_next = 6;
                        6: week_next = 8;
                        8: week_next = 1;
                    endcase
                end
            end
        end
    end

    
    always @(posedge clk_50MHz or negedge rst) //主程序
    begin
        if (!rst) //复位
        begin
            bit_sel <= 0;
            hour <= 0;
            min <= 0;
            sec <= 0;
            week <= 1;
        end
        else if (pause) //暂停
        begin
            if (!switch)
            begin
                if (left_pulse) //位 选左移动
                begin
                    bit_sel <= (bit_sel < 5) ? bit_sel + 1 : 0;
                end
                else if (right_pulse) //位选右移动
                begin
                    bit_sel <= (bit_sel > 0) ? bit_sel - 1 : 5;
                end           
                else if (plus_pulse) //对应位循环加
                begin
                    case(bit_sel)
                        0: sec <= (sec + 1) % 60;
                        1: sec <= (sec + 10) % 60;
                        2: min <= (min + 1) % 60;
                        3: min <= (min + 10) % 60;
                        4: hour <= (hour + 1) % 24;
                        5: hour <= (hour + 10) % 24;
                    endcase
                end                        
                else if (minus_pulse) //对应位循环减
                begin
                    case(bit_sel)
                        0: sec <= (sec - 1 + 60) % 60;
                        1: sec <= (sec - 10 + 60) % 60;
                        2: min <= (min - 1 + 60) % 60;
                        3: min <= (min - 10 + 60) % 60;
                        4: hour <= (hour - 1 + 24) % 24;
                        5: hour <= (hour - 10 + 24) % 24;
                    endcase
                end 
            end
            else
            begin 
                if (plus_pulse)
                begin
                    case (week)
                        1: week <= 2;
                        2: week <= 3;
                        3: week <= 4;
                        4: week <= 5;
                        5: week <= 6;
                        6: week <= 8;
                        8: week <= 1;
                    endcase
                end
                else if (minus_pulse)
                begin
                    case (week)
                        1: week <= 8;
                        2: week <= 1;
                        3: week <= 2;
                        4: week <= 3;
                        5: week <= 4;
                        6: week <= 5;
                        8: week <= 6;
                    endcase
                end
            end
        end
        else if (clk_pulse)
        begin
            hour <= hour_next;
            min <= min_next;
            sec <= sec_next;
            week <= week_next;
        end
        else if(!pause)
        begin
            bit_sel = 0;
        end
    end
endmodule