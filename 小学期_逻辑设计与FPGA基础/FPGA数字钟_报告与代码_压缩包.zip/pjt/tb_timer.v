`timescale 1ns / 1ns
module tb_timer;
reg clk;
reg clk_50MHz;
reg rst;
reg pause;
reg switch;
reg plus;
reg minus;
reg left;
reg right;
wire [2:0] bit_sel;
wire [5:0] hour;
wire [5:0] min;
wire [5:0] sec;
wire [3:0] week;


timer u_timer(
    .clk(clk),
    .clk_50MHz(clk_50MHz),
    .rst(rst),
    .pause(pause),
    .switch(switch),
    .plus(plus),
    .minus(minus),
    .left(left),
    .right(right),
    .bit_sel(bit_sel),
    .hour(hour),
    .min(min),
    .sec(sec),
    .week(week)
);

// 50MHz系统时钟 周期20ns
initial begin
    clk_50MHz = 1'b0;
    forever #1 clk_50MHz = ~clk_50MHz;
end

// 1Hz秒脉冲clk
initial begin
    clk = 1'b0;
    forever #50 clk = ~clk;
end

initial begin
    pause  = 1'b0; 
    switch = 1'b0;
    plus   = 1'b1;
    minus  = 1'b1;
    left   = 1'b1;
    right  = 1'b1;

    rst    = 1'b0; 
    #40;
    rst    = 1'b1;  // 释放复位
    
    //00:00:00 ~ 23:59:59 再回到00:00:00
    #90000;
    $finish;
end
endmodule