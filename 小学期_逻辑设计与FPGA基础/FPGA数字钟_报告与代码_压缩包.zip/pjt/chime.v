module chime (
    input clk_2kHz,
    input clk_800Hz,
    input pause,
    input [5:0]min,
    input [5:0]sec,
    output reg buzzer
    );

    always @(*)
    begin
        if(!pause)
        begin
            if(min == 59)
            begin
                case (sec)
                    50,52,54,56,58: 
                    begin
                        buzzer = clk_2kHz;
                    end
                    default: buzzer = 1;
                endcase
            end
            else if ((min == 0) && (sec == 0))
            begin
                buzzer = clk_800Hz;
            end
            else
            begin
                buzzer = 1;
            end
        end
        else
        begin
            buzzer = 1;
        end
    end
endmodule