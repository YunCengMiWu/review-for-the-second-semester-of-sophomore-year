module clk_2Hz_div(
    input clk, //输入时钟信号
    input clr, //低电平（按下）复位信号
    output clk_2Hz //输出时钟信号
    );
    /*
    50MHz分频至2Hz，即25M分频;
    从0计数到25M/2-1=12_499_999输出翻转一次;
    [log_2(12_499_999)]+1=24,使用24位二进制计数器
    */
    reg [23:0]cnt; 
    reg cnt_reg; //输出波形寄存器

    assign clk_2Hz = cnt_reg;

    initial //初始化
    begin
        cnt = 0;
        cnt_reg = 0;
    end

    always @(posedge clk or negedge clr) //时钟上升沿来临（计数同步）或复位信号下降沿出现（复位异步）
    begin
        if (!clr) //复位
        begin
            cnt <= 0; 
            cnt_reg <= 0;
        end
        else if (cnt == 12_499_999)
        begin
            cnt <= 0; //计数器清零
            cnt_reg <= ~cnt_reg; //输出信号翻转
        end
        else
        begin
            cnt <= cnt + 1; //计数
        end
    end
endmodule
