`timescale 1ns / 1ps
module tb_key_debounce;

reg btn_clk;
reg rst;
reg btn_in;
wire btn_out;

key_debounce u_key_debounce(
    .btn_clk(btn_clk),
    .rst(rst),
    .btn_in(btn_in),
    .btn_out(btn_out)
);



// 生成消抖采样时钟：假设1kHz，周期1000ns
initial begin
    btn_clk = 1'b0;
    forever #10000 btn_clk = ~btn_clk;
end


initial begin
    // 低电平复位
    rst = 1'b0;
    btn_in = 1'b1; // 按键默认松开高电平
    #40000;
    rst = 1'b1;    // 释放复位
    
    // 模拟按键按下，带短时抖动
    #60000;
    btn_in = 1'b0; #12000;
    btn_in = 1'b1; #8000;
    btn_in = 1'b0; #60000; // 稳定低电平
    
    // 长按保持
    #100000;
    
    // 模拟按键松开，带抖动
    btn_in = 1'b1; #14000;
    btn_in = 1'b0; #6000;
    btn_in = 1'b1; #60000;
    
    #40000;
    $finish;
end

endmodule