`timescale 1ns / 1ns
module tb_bin_to_bcd;
reg [5:0] bin;
wire [7:0] bcd;

bin_to_bcd uut(
    .bin(bin),
    .bcd(bcd)
);

initial begin
    for(bin = 0; bin <= 60; bin = bin + 1) begin
        #10;
    end
    #10;
    $finish;
end
endmodule