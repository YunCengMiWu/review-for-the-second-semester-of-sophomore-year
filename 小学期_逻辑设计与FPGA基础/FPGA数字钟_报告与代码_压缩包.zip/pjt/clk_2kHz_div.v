module clk_2kHz_div(
    input clk, //输入时钟信号
    input clr, //低电平（按下）复位信号
    output clk_2kHz //输出时钟信号
    );
    /*
    50MHz分频至2kHz，即25k分频;
    从0计数到25k/2-1=12_499输出翻转一次;
    [log_2(12_499)]+1=14,使用14位二进制计数器
    */
    reg [13:0]cnt; 
    reg cnt_reg; //输出波形寄存器

    assign clk_2kHz = cnt_reg;

    initial //初始化
    begin
        cnt = 0;
        cnt_reg = 0;
    end

    always @(posedge clk or negedge clr) //时钟上升沿来临（计数同步）或复位信号下降沿出现（复位异步）
    begin
        if (!clr) //复位
        begin
            cnt <= 0; 
            cnt_reg <= 0;
        end
        else if (cnt == 12_499)
        begin
            cnt <= 0; //计数器清零
            cnt_reg <= ~cnt_reg; //输出信号翻转
        end
        else
        begin
            cnt <= cnt + 1; //计数
        end
    end
endmodule
