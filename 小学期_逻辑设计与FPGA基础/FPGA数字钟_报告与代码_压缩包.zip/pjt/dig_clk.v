module dig_clk(
    input clk, 
    input rst,
    input pause, 
    input plus, 
    input minus,
    input left,
    input right,
    input switch, //切换时间和星期
    output [7:0]seg, //数码管
    output [5:0]an,
    output buzzer //蜂鸣器
    );

    wire clk_1Hz;
    wire clk_2Hz;
    wire clk_50Hz;
    wire clk_800Hz;
    wire clk_1kHz;
    wire clk_2kHz;

    wire plus_deb;
    wire minus_deb;
    wire left_deb;
    wire right_deb;
    wire pause_deb;

    wire [5:0]hour;
    wire [5:0]min;
    wire [5:0]sec;
    wire [3:0]week;

    wire [7:0]hour_BCD;
    wire [7:0]min_BCD;
    wire [7:0]sec_BCD;
    wire [3:0]week_BCD;

    wire [23:0]dispdata;

    wire [2:0]bit_sel;
    wire [2:0]bit_sel_time;

	clk_1Hz_div u_clk_1Hz_div(
        .clk(clk), 
        .clr(rst),
        .clk_1Hz(clk_1Hz)
    );

    clk_2Hz_div u_clk_2Hz_div(
        .clk(clk), 
        .clr(rst),
        .clk_2Hz(clk_2Hz)
    );

    clk_50Hz_div u_clk_50Hz_div(
        .clk(clk), 
        .clr(rst),
        .clk_50Hz(clk_50Hz)
    );

    clk_800Hz_div u_clk_800Hz_div(
        .clk(clk), 
        .clr(rst),
        .clk_800Hz(clk_800Hz)
    );

    clk_1kHz_div u_clk_1kHz_div(
        .clk(clk), 
        .clr(rst),
        .clk_1kHz(clk_1kHz)
    );

    clk_2kHz_div u_clk_2kHz_div(
        .clk(clk), 
        .clr(rst),
        .clk_2kHz(clk_2kHz)
    );

    key_debounce u_key_plus (
    .btn_clk(clk_50Hz),
    .rst(rst),
    .btn_in(plus),
    .btn_out(plus_deb)
    );

    key_debounce u_key_minus (
        .btn_clk(clk_50Hz),
        .rst(rst),
        .btn_in(minus),
        .btn_out(minus_deb)
    );

    key_debounce u_key_left (
        .btn_clk(clk_50Hz),
        .rst(rst),
        .btn_in(left),
        .btn_out(left_deb)
    );

    key_debounce u_key_right (
        .btn_clk(clk_50Hz),
        .rst(rst),
        .btn_in(right),
        .btn_out(right_deb)
    );

    key_debounce u_key_pause (
        .btn_clk(clk_50Hz),
        .rst(rst),
        .btn_in(pause),
        .btn_out(pause_deb)
    );

    bin_to_bcd u_bin_to_bcd_year(
        .bin(hour),
        .bcd(hour_BCD) 
    );

    bin_to_bcd u_bin_to_bcd_month(
        .bin(min),
        .bcd(min_BCD) 
    );

    bin_to_bcd u_bin_to_bcd_day(
        .bin(sec),
        .bcd(sec_BCD) 
    );

    bin_to_bcd u_bin_to_bcd_week(
        .bin(week),
        .bcd(week_BCD) 
    );

    dig_disp u_dig_disp (
        .clk(clk_1kHz),
        .clk_flk(clk_2Hz),
        .rst(rst),
        .pause(pause_deb),
        .dispdata_bcd(dispdata),
        .bit_sel(bit_sel),
        .an(an),
        .seg(seg)
    );

    timer u_timer(
        .clk(clk_1Hz),
        .clk_50MHz(clk),
        .rst(rst),
        .pause(pause_deb),
        .switch(switch),
        .plus(plus_deb),
        .minus(minus_deb),
        .left(left_deb),
        .right(right_deb),
        .bit_sel(bit_sel_time),
        .hour(hour),
        .min(min),
        .sec(sec),
        .week(week)
    );

    disp_change u_disp_change(
        .switch(switch),
        .timing({hour_BCD, min_BCD, sec_BCD}),
        .week({20'hFFFFF, week_BCD}),
        .bit_sel_time(bit_sel_time),
        .dispdata(dispdata),
        .bit_sel(bit_sel)
    );

    chime u_chime(
        .clk_2kHz(clk_2kHz),
        .clk_800Hz(clk_800Hz),
        .pause(pause),
        .min(min),
        .sec(sec),
        .buzzer(buzzer)
    );
endmodule